class CoreGroup:
    def __init__(self) -> None:
        self.name = ""
        self.groups = {}
        self.rom_total = 0
        self.ram_total = 0
        self.calib_total = 0