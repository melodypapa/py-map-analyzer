class FileProperty:
    def __init__(self) -> None:
        self.name = ""
        self.group = ""

    