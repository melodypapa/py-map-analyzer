class CoreGroup:
    def __init__(self) -> None:
        self.name = ""
        self.groups = {}